# Vision-Ops
Vision Ops SDK - Training pipeline
